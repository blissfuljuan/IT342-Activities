package com.obeso.contactsapp;

import io.github.cdimascio.dotenv.Dotenv;
import org.springframework.context.annotation.Configuration;

@Configuration
public class EnvConfig {
    public static void main(String[] args) {
        Dotenv dotenv = Dotenv.load(); // Loads the .env file

        String clientId = dotenv.get("GOOGLE_CLIENT_ID");
        String clientSecret = dotenv.get("GOOGLE_CLIENT_SECRET");

        System.out.println("GOOGLE_CLIENT_ID: " + clientId);
        System.out.println("GOOGLE_CLIENT_SECRET: " + clientSecret);
    }
}
