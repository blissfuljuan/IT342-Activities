package com.obeso.contactsapp;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import java.util.List;

@JsonIgnoreProperties(ignoreUnknown = true)
public class GoogleContact {
    private String resourceName;  // Required for updating/deleting
    private String etag;          // Required for updates
    private List<Name> names;
    private List<Email> emailAddresses;
    private List<PhoneNumber> phoneNumbers; // New: To store phone numbers

    // Getters and Setters
    public String getResourceName() { return resourceName; }
    public void setResourceName(String resourceName) { this.resourceName = resourceName; }

    public String getEtag() { return etag; }
    public void setEtag(String etag) { this.etag = etag; }

    public List<Name> getNames() { return names; }
    public void setNames(List<Name> names) { this.names = names; }

    public List<Email> getEmailAddresses() { return emailAddresses; }
    public void setEmailAddresses(List<Email> emailAddresses) { this.emailAddresses = emailAddresses; }

    public List<PhoneNumber> getPhoneNumbers() { return phoneNumbers; }
    public void setPhoneNumbers(List<PhoneNumber> phoneNumbers) { this.phoneNumbers = phoneNumbers; }

    // Inner Classes
    @JsonIgnoreProperties(ignoreUnknown = true)
    public static class Name {
        private String displayName;

        public String getDisplayName() { return displayName; }
        public void setDisplayName(String displayName) { this.displayName = displayName; }
    }

    @JsonIgnoreProperties(ignoreUnknown = true)
    public static class Email {
        private String value;

        public String getValue() { return value; }
        public void setValue(String value) { this.value = value; }
    }

    @JsonIgnoreProperties(ignoreUnknown = true)
    public static class PhoneNumber { // New: Handles phone numbers
        private String value;

        public String getValue() { return value; }
        public void setValue(String value) { this.value = value; }
    }
}
