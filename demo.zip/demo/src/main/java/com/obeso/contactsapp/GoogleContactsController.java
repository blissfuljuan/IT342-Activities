package com.obeso.contactsapp;

import org.springframework.security.core.annotation.AuthenticationPrincipal;
import org.springframework.security.oauth2.client.OAuth2AuthorizedClient;
import org.springframework.security.oauth2.client.OAuth2AuthorizedClientService;
import org.springframework.security.oauth2.client.authentication.OAuth2AuthenticationToken;
import org.springframework.security.oauth2.core.user.OAuth2User;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;

import java.util.Optional;

@Controller
@RequestMapping("/contacts")
public class GoogleContactsController {
    private final GoogleContactsService contactsService;
    private final OAuth2AuthorizedClientService authorizedClientService;

    public GoogleContactsController(GoogleContactsService contactsService, OAuth2AuthorizedClientService authorizedClientService) {
        this.contactsService = contactsService;
        this.authorizedClientService = authorizedClientService;
    }

    // ✅ Helper method to get access token
    private Optional<String> getAccessToken(OAuth2AuthenticationToken authenticationToken) {
        OAuth2AuthorizedClient client = authorizedClientService.loadAuthorizedClient(
                authenticationToken.getAuthorizedClientRegistrationId(),
                authenticationToken.getName());

        return client != null && client.getAccessToken() != null
                ? Optional.of(client.getAccessToken().getTokenValue())
                : Optional.empty();
    }

    // ✅ Fetch and Display Contacts
    @GetMapping
    public String showContacts(Model model, @AuthenticationPrincipal OAuth2User principal,
                               OAuth2AuthenticationToken authenticationToken) {
        if (principal == null) {
            return "redirect:/login";
        }

        Optional<String> accessToken = getAccessToken(authenticationToken);
        if (accessToken.isEmpty()) {
            return "redirect:/error";
        }

        GoogleContactsResponse contacts = contactsService.getContacts(accessToken.get());
        model.addAttribute("contacts", contacts.getConnections());

        return "contacts"; // Thymeleaf template
    }

    // ✅ Show Add Contact Form
    @GetMapping("/add")
    public String showAddContactForm(Model model) {
        model.addAttribute("contact", new GoogleContact());
        return "add-contact"; // Thymeleaf template
    }

    // ✅ Process Adding a Contact
    @PostMapping("/add")
    public String addContact(@ModelAttribute GoogleContact contact, OAuth2AuthenticationToken authenticationToken) {
        Optional<String> accessToken = getAccessToken(authenticationToken);
        if (accessToken.isEmpty()) {
            return "redirect:/error";
        }

        contactsService.addContact(accessToken.get(), contact);
        return "redirect:/contacts";
    }

    // ✅ Show Edit Contact Form
    @GetMapping("/edit/{resourceName}")
    public String showEditContactForm(@PathVariable String resourceName, Model model, OAuth2AuthenticationToken authenticationToken) {
        Optional<String> accessToken = getAccessToken(authenticationToken);
        if (accessToken.isEmpty()) {
            return "redirect:/error";
        }

        GoogleContactsResponse contacts = contactsService.getContacts(accessToken.get());
        GoogleContact contactToEdit = contacts.getConnections().stream()
                .filter(contact -> contact.getResourceName().equals(resourceName))
                .findFirst()
                .orElse(null);

        if (contactToEdit == null) {
            return "redirect:/contacts";
        }

        model.addAttribute("contact", contactToEdit);
        return "edit-contact"; // Thymeleaf template
    }

    // ✅ Process Editing a Contact
    @PostMapping("/edit")
    public String editContact(@ModelAttribute GoogleContact contact, OAuth2AuthenticationToken authenticationToken) {
        Optional<String> accessToken = getAccessToken(authenticationToken);
        if (accessToken.isEmpty()) {
            return "redirect:/error";
        }

        contactsService.updateContact(accessToken.get(), contact);
        return "redirect:/contacts";
    }

    // ✅ Delete a Contact
    @GetMapping("/delete/people/{resourceName}")
    public String deleteContact(@PathVariable String resourceName, OAuth2AuthenticationToken authenticationToken) {
        Optional<String> accessToken = getAccessToken(authenticationToken);
        if (accessToken.isEmpty()) {
            return "redirect:/error";
        }

        contactsService.deleteContact(accessToken.get(), resourceName);
        return "redirect:/contacts";
    }
}
