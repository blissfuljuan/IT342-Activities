package com.obeso.contactsapp;

import com.fasterxml.jackson.databind.ObjectMapper;
import org.springframework.http.*;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;
import java.util.HashMap;
import java.util.Map;

@Service
public class GoogleContactsService {
    private final RestTemplate restTemplate;
    private final ObjectMapper objectMapper;

    public GoogleContactsService() {
        this.restTemplate = new RestTemplate();
        this.objectMapper = new ObjectMapper();
    }

    // ✅ Fetch Contacts
    public GoogleContactsResponse getContacts(String accessToken) {
        String url = "https://people.googleapis.com/v1/people/me/connections?personFields=names,emailAddresses,phoneNumbers";

        HttpHeaders headers = new HttpHeaders();
        headers.set("Authorization", "Bearer " + accessToken);

        HttpEntity<String> requestEntity = new HttpEntity<>(headers);

        try {
            ResponseEntity<String> response = restTemplate.exchange(url, HttpMethod.GET, requestEntity, String.class);
            return objectMapper.readValue(response.getBody(), GoogleContactsResponse.class);
        } catch (Exception e) {
            e.printStackTrace();
            return new GoogleContactsResponse(); // Return empty object if error occurs
        }
    }

    // ✅ Add Contact
    public boolean addContact(String accessToken, GoogleContact contact) {
        String url = "https://people.googleapis.com/v1/people:createContact";

        Map<String, Object> requestBody = new HashMap<>();
        if (contact.getNames() != null && !contact.getNames().isEmpty()) {
            requestBody.put("names", new Object[]{Map.of("givenName", contact.getNames().get(0).getDisplayName())});
        }
        if (contact.getEmailAddresses() != null && !contact.getEmailAddresses().isEmpty()) {
            requestBody.put("emailAddresses", new Object[]{Map.of("value", contact.getEmailAddresses().get(0).getValue())});
        }
        if (contact.getPhoneNumbers() != null && !contact.getPhoneNumbers().isEmpty()) {
            requestBody.put("phoneNumbers", new Object[]{Map.of("value", contact.getPhoneNumbers().get(0).getValue())});
        }

        HttpHeaders headers = new HttpHeaders();
        headers.setContentType(MediaType.APPLICATION_JSON);
        headers.set("Authorization", "Bearer " + accessToken);

        HttpEntity<Map<String, Object>> requestEntity = new HttpEntity<>(requestBody, headers);

        try {
            ResponseEntity<String> response = restTemplate.postForEntity(url, requestEntity, String.class);
            return response.getStatusCode().is2xxSuccessful();
        } catch (Exception e) {
            e.printStackTrace();
            return false;
        }
    }

    // ✅ Update Contact
    public boolean updateContact(String accessToken, GoogleContact contact) {
        String url = "https://people.googleapis.com/v1/" + contact.getResourceName() + "?updatePersonFields=names,emailAddresses,phoneNumbers";

        Map<String, Object> requestBody = new HashMap<>();
        requestBody.put("etag", contact.getEtag()); // Required for updating
        if (contact.getNames() != null && !contact.getNames().isEmpty()) {
            requestBody.put("names", new Object[]{Map.of("givenName", contact.getNames().get(0).getDisplayName())});
        }
        if (contact.getEmailAddresses() != null && !contact.getEmailAddresses().isEmpty()) {
            requestBody.put("emailAddresses", new Object[]{Map.of("value", contact.getEmailAddresses().get(0).getValue())});
        }
        if (contact.getPhoneNumbers() != null && !contact.getPhoneNumbers().isEmpty()) {
            requestBody.put("phoneNumbers", new Object[]{Map.of("value", contact.getPhoneNumbers().get(0).getValue())});
        }

        HttpHeaders headers = new HttpHeaders();
        headers.setContentType(MediaType.APPLICATION_JSON);
        headers.set("Authorization", "Bearer " + accessToken);

        HttpEntity<Map<String, Object>> requestEntity = new HttpEntity<>(requestBody, headers);

        try {
            ResponseEntity<String> response = restTemplate.exchange(url, HttpMethod.PATCH, requestEntity, String.class);
            return response.getStatusCode().is2xxSuccessful();
        } catch (Exception e) {
            e.printStackTrace();
            return false;
        }
    }

    // ✅ Delete Contact
    public boolean deleteContact(String accessToken, String resourceName) {
        String url = "https://people.googleapis.com/v1/" + resourceName + ":deleteContact";

        HttpHeaders headers = new HttpHeaders();
        headers.set("Authorization", "Bearer " + accessToken);

        HttpEntity<String> requestEntity = new HttpEntity<>(headers);

        try {
            ResponseEntity<String> response = restTemplate.exchange(url, HttpMethod.DELETE, requestEntity, String.class);
            return response.getStatusCode().is2xxSuccessful();
        } catch (Exception e) {
            e.printStackTrace();
            return false;
        }
    }
}
